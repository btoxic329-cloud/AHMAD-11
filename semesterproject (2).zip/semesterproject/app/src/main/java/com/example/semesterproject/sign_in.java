package com.example.semesterproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class sign_in extends AppCompatActivity {

    EditText etEmail, etPassword;
    Button btnLogin, btnGoToSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnGoToSignup = findViewById(R.id.btnGoToSignup);


        btnGoToSignup.setOnClickListener(view -> {
            Intent intent = new Intent(sign_in.this, SignupActivity.class);
            startActivity(intent);
        });


        btnLogin.setOnClickListener(view -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(sign_in.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
                return;
            }


            SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
            String savedEmail = prefs.getString("email", "");
            String savedPassword = prefs.getString("password", "");

            if (email.equals(savedEmail) && password.equals(savedPassword)) {
                Toast.makeText(sign_in.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                // TODO: Go to home/dashboard screen
                Intent intent = new Intent(sign_in.this, ClassSelectionActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(sign_in.this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
