package com.example.semesterproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class ClassSelectionActivity extends AppCompatActivity {

    Button btnSection5A, btnSection5B, btnsummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_selection);

        btnSection5A = findViewById(R.id.btnSection5A);
        btnSection5B = findViewById(R.id.btnSection5B);
        btnsummary = findViewById(R.id.summary);


        btnSection5A.setOnClickListener(v -> {
            Intent intent = new Intent(
                    ClassSelectionActivity.this,
                    activity_attendance.class
            );
            intent.putExtra("section", "5A Eve");
            startActivity(intent);
        });


        btnSection5B.setOnClickListener(v -> {
            Intent intent = new Intent(
                    ClassSelectionActivity.this,
                    activity_attendance.class
            );
            intent.putExtra("section", "5B Eve");
            startActivity(intent);
        });


        btnsummary.setOnClickListener(v -> {
            Intent intent = new Intent(
                    ClassSelectionActivity.this,
                    activity_attendance_summary.class
            );


            intent.putExtra("section", "5A Eve");
            intent.putExtra("total", 5);
            intent.putExtra("present", 3);
            intent.putExtra("absent", 2);

            startActivity(intent);
        });
    }
}
