package com.example.semesterproject;

public class StudentModel {
    private final String name;
    private boolean present;

    public StudentModel(String name) {
        this.name = name;
        this.present = false;
    }

    public String getName() {
        return name;
    }

    public boolean isPresent() {
        return present;
    }

    public void setPresent(boolean present) {
        this.present = present;
    }
}
