package com.example.semesterproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class activity_attendance extends AppCompatActivity {

    TextView tvSectionName;
    ListView studentListView;
    Button btnSave;

    ArrayList<StudentModel> students;
    StudentAdapter adapter;
    AttendanceDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        tvSectionName = findViewById(R.id.tvSectionName);
        studentListView = findViewById(R.id.studentListView);
        btnSave = findViewById(R.id.btnSaveAttendance);

        dbHelper = new AttendanceDatabaseHelper(this);


        String section = getIntent().getStringExtra("section");
        if (section == null) {
            section = "Unknown Section";
        }

        tvSectionName.setText("Mark Attendance - " + section);

        // Student list
        students = new ArrayList<>();
        students.add(new StudentModel("Ali"));
        students.add(new StudentModel("Ahmed"));
        students.add(new StudentModel("Sara"));
        students.add(new StudentModel("Ayesha"));
        students.add(new StudentModel("Hamza"));

        adapter = new StudentAdapter(this, students);
        studentListView.setAdapter(adapter);

        String finalSection = section;
        btnSave.setOnClickListener(v -> {

            int presentCount = 0;


            String date = new SimpleDateFormat(
                    "dd-MM-yyyy",
                    Locale.getDefault()
            ).format(new Date());

            for (StudentModel student : students) {

                String status = student.isPresent() ? "Present" : "Absent";

                dbHelper.insertAttendance(
                        finalSection,
                        student.getName(),
                        date,
                        status
                );

                if (student.isPresent()) {
                    presentCount++;
                }
            }

            Intent intent = new Intent(
                    activity_attendance.this,
                    activity_attendance_summary.class
            );

            intent.putExtra("section", finalSection);
            intent.putExtra("total", students.size());
            intent.putExtra("present", presentCount);

            startActivity(intent);
        });
    }
}
