package com.example.semesterproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

public class StudentAdapter extends BaseAdapter {

    Context context;
    ArrayList<StudentModel> students;

    public StudentAdapter(Context context, ArrayList<StudentModel> students) {
        this.context = context;
        this.students = students;
    }

    @Override
    public int getCount() {
        return students.size();
    }

    @Override
    public Object getItem(int i) {
        return students.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        @SuppressLint("ViewHolder") View view = LayoutInflater.from(context).inflate(R.layout.student_item, parent, false);

        TextView tvName = view.findViewById(R.id.tvStudentName);
        CheckBox cbPresent = view.findViewById(R.id.cbPresent);

        StudentModel student = students.get(position);

        tvName.setText(student.getName());
        cbPresent.setChecked(student.isPresent());

        cbPresent.setOnCheckedChangeListener((buttonView, isChecked) -> {
            student.setPresent(isChecked);
        });

        return view;
    }
}
