package com.example.semesterproject;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class activity_attendance_summary extends AppCompatActivity {

    TextView tvSection, tvTotal, tvPresent, tvAbsent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_summary);

        tvSection = findViewById(R.id.tvSection);
        tvTotal = findViewById(R.id.tvTotal);
        tvPresent = findViewById(R.id.tvPresent);
        tvAbsent = findViewById(R.id.tvAbsent);

        String section = getIntent().getStringExtra("section");
        int total = getIntent().getIntExtra("total", 0);
        int present = getIntent().getIntExtra("present", 0);
        int absent = getIntent().getIntExtra("absent", 0);

        tvSection.setText("Section: " + section);
        tvTotal.setText("Total Students: " + total);
        tvPresent.setText("Present: " + present);
        tvAbsent.setText("Absent: " + absent);
    }
}
